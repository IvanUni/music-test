// let words = {
//   "cat": "кошка",
//   "run": "бежать",
//   "school": "школа"
// }

let words = {
  "cat": {
    translation: "кошка",
    transcrition: "[kæt]",
    example: `It was not the only cat.
    И это была не единственная кошка.`
  },
  "run": {
    translation: "бежать, бегать",
    transcrition: "[rʌn]"
  },
  "school": {
    translation: "школа",
    transcrition: "[skuːl]",
    example: `He was given music lessons, and when he was five he attended dancing school .
    Он ходил на уроки музыки, а с пяти лет учился в танцевальной школе .`
  }
}



let input = document.querySelector(`#input`);
let result = document.querySelector(`#result`);

input.addEventListener(`input`, function () {
  let value = input.value;

  let word = words[value];

  if (word) {
    result.innerHTML = `
        <h5 class="card-title">${word.translation}</h5>
        <h6 class="card-subtitle mb-2 text-muted">${word.transcrition}</h6>
        <p class="card-text">${word.example}</p>
    `;
  } else {
    result.innerHTML = `
      <h5 class="card-title">-</h5>
    `
  }

});